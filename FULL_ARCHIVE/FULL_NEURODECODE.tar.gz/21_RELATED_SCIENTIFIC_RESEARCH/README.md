# 21 Related Scientific Research

**Project:** NEURODECODE
**Upstream:** https://github.com/nicedoc/neurodecode

Content specific to NEURODECODE in category BRAIN_COMPUTER_INTERFACE.
