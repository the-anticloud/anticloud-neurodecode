# OSINT Benchmark — NEURODECODE

**Upstream:** https://github.com/nicedoc/neurodecode

Public-record information collected about upstream project:

- GitHub stars: see upstream
- License: MIT
- Last commit: check upstream
- Known CVEs: check NVD

Status: PENDING systematic collection.
